import { StyleSheet } from "react-native";

export default StyleSheet.create({
    image:{
        width:150,
        height:150,
        alignSelf:'center'
    }
});