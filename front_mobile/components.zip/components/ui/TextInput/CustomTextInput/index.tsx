import { TextStyle, ViewStyle } from "react-native/Libraries/StyleSheet/StyleSheetTypes";
import styles from "./styles"

type CustomTextInputProps={
    hint?:string;
    defaultValue?:string;
    containerStyle?:ViewStyle
    inputStyle?:TextStyle;
};

export default function CustomTextInput({
    hint,
    defaultValue,
    containerStyle,
    inputStyle
}:CustomTextInputProps){

}

